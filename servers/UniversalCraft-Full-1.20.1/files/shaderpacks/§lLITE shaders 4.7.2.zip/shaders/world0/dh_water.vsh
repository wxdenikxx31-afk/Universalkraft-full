#version 120
/* MakeUp - LITE shaders 4.7.2 - dh_water.vsh
Render: DH Water

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define DH_WATER

#include "/common/solid_dh_water_vertex.glsl"
