#version 120
/* MakeUp - LITE shaders 4.7.2 - composite1.fsh
Render: Bloom and DoF

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define COMPOSITE1_SHADER

#include "/common/composite1_fragment.glsl"