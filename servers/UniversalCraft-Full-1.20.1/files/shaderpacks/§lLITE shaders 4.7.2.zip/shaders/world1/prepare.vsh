#version 120
/* MakeUp - LITE shaders 4.7.2 - prepare.vsh
Render: Sky

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define PREPARE_SHADER
#define NO_SHADOWS

#include "/common/prepare_vertex.glsl"