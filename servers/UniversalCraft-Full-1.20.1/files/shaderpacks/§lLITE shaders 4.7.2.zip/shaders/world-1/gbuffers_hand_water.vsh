#version 120
/* MakeUp - LITE shaders 4.7.2 - gbuffers_hand_water.vsh
Render: Translucent hand objects

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_HAND_WATER
#define NO_SHADOWS

#include "/common/solid_blocks_vertex.glsl"
