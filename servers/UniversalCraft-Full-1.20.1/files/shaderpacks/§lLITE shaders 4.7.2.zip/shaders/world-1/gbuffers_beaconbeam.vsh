#version 120
/* MakeUp - LITE shaders 4.7.2 - gbuffers_beaconbeam.vsh
Render: Beacon beam

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_BEACONBEAM

#include "/common/solid_blocks_vertex.glsl"
